CMAKE_ANDROID_SKIP_ANT_STEP
---------------------------

.. versionadded:: 3.4

Default value for the :prop_tgt:`ANDROID_SKIP_ANT_STEP` target property.
See that target property for additional information.
