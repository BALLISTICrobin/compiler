CMAKE_<LANG>_ANDROID_TOOLCHAIN_SUFFIX
-------------------------------------

.. versionadded:: 3.7

When :ref:`Cross Compiling for Android` this variable contains the
host platform suffix of the toolchain GNU compiler and its binutils.

See also :variable:`CMAKE_<LANG>_ANDROID_TOOLCHAIN_PREFIX`
and :variable:`CMAKE_<LANG>_ANDROID_TOOLCHAIN_MACHINE`.
